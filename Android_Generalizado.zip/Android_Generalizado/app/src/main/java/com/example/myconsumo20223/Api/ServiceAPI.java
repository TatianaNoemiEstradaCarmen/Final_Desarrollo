package com.example.myconsumo20223.Api;
import com.example.myconsumo20223.Model.Horario;

import java.util.List;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.DELETE;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Path;
public interface ServiceAPI {
    @GET("horario")
    public abstract Call<List<Horario>> listHorario();
    @POST("horario/agregar")
    public abstract Call<Horario> addHorario(@Body Horario obj);
    @PUT("horario/modificar")
    public abstract Call<Horario> modifyHorario(@Body Horario obj);
    @DELETE("horario/eliminar/{id}")
    public abstract Call<Horario> removeHorario(@Path("id") int id);
}