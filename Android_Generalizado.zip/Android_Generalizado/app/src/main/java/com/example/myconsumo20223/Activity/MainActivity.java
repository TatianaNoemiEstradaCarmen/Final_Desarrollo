package com.example.myconsumo20223.Activity;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;

import com.example.myconsumo20223.Api.ServiceAPI;
import com.example.myconsumo20223.Model.Horario;
import com.example.myconsumo20223.R;
import com.example.myconsumo20223.Util.ConnectionREST;

import java.sql.Time;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {
    private EditText _etResultado;
    private EditText _etCodigo;
    private EditText _etFecha;
    private EditText _etHora;
    private EditText _etStock;
    private Button _btnGrabar;
    private Button _btnModificar;
    private Button _btnEliminar;
    private ServiceAPI serviceAPI;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        _etCodigo = (EditText) findViewById(R.id.etCodigo);
        _etFecha = (EditText) findViewById(R.id.editTextDate);
        _etHora = (EditText) findViewById(R.id.editTextTime);
        _etStock = (EditText) findViewById(R.id.etStock);
        _etResultado = (EditText) findViewById(R.id.etResultado);
        _btnGrabar = (Button) findViewById(R.id.btnProcesar);
        _btnModificar = (Button) findViewById(R.id.btnModificar);
        _btnEliminar = (Button) findViewById(R.id.btnEliminar);


        serviceAPI = ConnectionREST.getConnection().create(ServiceAPI.class);

        load();

        _etFecha.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Obtén la fecha actual
                Calendar calendar = Calendar.getInstance();
                int year = calendar.get(Calendar.YEAR);
                int month = calendar.get(Calendar.MONTH);
                int dayOfMonth = calendar.get(Calendar.DAY_OF_MONTH);

                // Crea y muestra el DatePickerDialog
                DatePickerDialog datePickerDialog = new DatePickerDialog(MainActivity.this,
                        new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                                // Actualiza el texto del EditTextDate con la fecha seleccionada
                                String selectedDate = dayOfMonth + "/" + (monthOfYear + 1) + "/" + year;
                                _etFecha.setText(selectedDate);
                            }
                        }, year, month, dayOfMonth);

                datePickerDialog.show();
            }
        });

        _btnGrabar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String fechaString = _etFecha.getText().toString();
                SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
                Date fecha;
                Time hora;
                try {
                    fecha = dateFormat.parse(fechaString);
                } catch (ParseException e) {
                    fecha = null;
                }
                String horaString = _etHora.getText().toString();

                try {
                    SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");
                    Date date = sdf.parse(horaString);
                    hora = new Time(date.getTime());
                } catch (ParseException e) {
                    e.printStackTrace();
                    hora = null;
                }
                Horario hObj = new Horario(Integer.parseInt(_etCodigo.getText().toString()),
                                fecha,
                                hora,
                                Integer.parseInt(_etStock.getText().toString())
                                    );
                addHorario(hObj);
            }
        });

        _btnEliminar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                eliminarHorario(Integer.parseInt(_etCodigo.getText().toString()));
            }
        });

        _btnModificar.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view) {
                String fechaString = _etFecha.getText().toString();
                SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
                Date fecha;
                Time hora;
                try {
                    fecha = dateFormat.parse(fechaString);
                } catch (ParseException e) {
                    fecha = null;
                }
                String horaString = _etHora.getText().toString();

                try {
                    SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");
                    Date date = sdf.parse(horaString);
                    hora = new Time(date.getTime());
                } catch (ParseException e) {
                    e.printStackTrace();
                    hora = null;
                }
                Horario hObj = new Horario(Integer.parseInt(_etCodigo.getText().toString()),
                        fecha,
                        hora,
                        Integer.parseInt(_etStock.getText().toString())
                );
                modifyHorario(hObj);
            }
        });
    }

    private void eliminarHorario(int parseInt) {
        Call<Horario> call = serviceAPI.removeHorario(parseInt);
        call.enqueue(new Callback<Horario>() {
            @Override
            public void onResponse(Call<Horario> call, Response<Horario> response) {
                if(response.isSuccessful())
                {
                    mensaje("Los datos se eliminaron satisfactoriamente!!!");
                }
                else
                {
                    mensaje("Ocurrio un error desconocido!!!");
                }
            }

            @Override
            public void onFailure(Call<Horario> call, Throwable t) {
                mensaje("Ocurrio un error!!!" + t.getMessage());
            }
        });
    }

    private void modifyHorario(Horario hObj) {
        Call<Horario> call = serviceAPI.modifyHorario(hObj);
        call.enqueue(new Callback<Horario>() {
            @Override
            public void onResponse(Call<Horario> call, Response<Horario> response) {
                if(response.isSuccessful())
                {
                    Horario hor = response.body();

                    mensaje("Los datos se modificaron satisfactoriamente!!!");
                }
                else
                {
                    mensaje("Ocurrio un error desconocido!!!");
                }
            }

            @Override
            public void onFailure(Call<Horario> call, Throwable t) {
                mensaje("Ocurrio un error!!!" + t.getMessage());
            }
        });
    }

    public void addHorario(Horario hObj)
    {
         Call<Horario> call = serviceAPI.addHorario(hObj);
         call.enqueue(new Callback<Horario>() {
             @Override
             public void onResponse(Call<Horario> call, Response<Horario> response) {
                if(response.isSuccessful())
                {
                    Horario hor = response.body();
                    mensaje("Registro grabado satisfactoriamente!");
                }
                else
                {
                    mensaje("Ocurrio un error al grabar los datos!");
                }
             }
             @Override
             public void onFailure(Call<Horario> call, Throwable t) {
                 mensaje("Ocurrio un error desconocido!" + t.getMessage());
             }
         });
    }

    public void load()
    {
        //ServiceAPI serviceAPI = ConnectionREST.getConnection().create(ServiceAPI.class);
        Call<List<Horario>> call = serviceAPI.listHorario();
        call.enqueue(new Callback<List<Horario>>() {
            @Override
            public void onResponse(Call<List<Horario>> call, Response<List<Horario>> response) {
                if(response.isSuccessful())
                {
                    List<Horario> respuesta = response.body();
                    _etResultado.setText("\n\n\n\n");
                    for(Horario x:respuesta)
                    {
                        _etResultado.append("Id:" + x.getIdHorario()+ "\nFecha:" + x.getFecha()+ "\nHora:" + x.getHora() + "\nTamaño de mesa:" + x.getTamaño() + "\n");
                        Toast.makeText(getApplicationContext(),"" + x.getTamaño(), Toast.LENGTH_LONG).show();
                        mensaje(x.getIdHorario() + "-" + x.getTamaño());
                    }
                }
                else
                {
                    Toast.makeText(null,"Error", Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onFailure(Call<List<Horario>> call, Throwable t) {
                Toast.makeText(null,"Ocurrop un error", Toast.LENGTH_LONG).show();
            }
        });
    }
    public void mensaje(String msg)
    {
        AlertDialog.Builder alerta = new AlertDialog.Builder(this);
        alerta.setMessage(msg);
        alerta.show();
    }
}