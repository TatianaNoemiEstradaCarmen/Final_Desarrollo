package com.example.myconsumo20223.Model;

import java.sql.Time;
import java.util.Date;

public class Horario {
    private int idHorario;
    private Date Fecha;
    private Time Hora;
    private int tamaño;

    public Horario(int idHorario, Date fecha, Time hora, int tamaño) {
        this.idHorario = idHorario;
        this.Fecha = fecha;
        this.Hora = hora;
        this.tamaño = tamaño;
    }

    public Horario() {
    }

    public int getIdHorario() {
        return idHorario;
    }

    public void setIdHorario(int idHorario) {
        this.idHorario = idHorario;
    }

    public Date getFecha() {
        return Fecha;
    }

    public void setFecha(Date fecha) {
        this.Fecha = fecha;
    }

    public Time getHora() {
        return Hora;
    }

    public void setHora(Time hora) {
        this.Hora = hora;
    }

    public int getTamaño() {
        return tamaño;
    }

    public void setTamaño(int tamaño) {
        this.tamaño = tamaño;
    }
}
